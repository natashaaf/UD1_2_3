<?php

require_once 'usuarios.php';

// Comprobar que la petición procede de un formulario POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit;
}

// Comprobar que se han recibido las credenciales
if (
    !isset($_POST['usuario'], $_POST['password']) ||
    !is_string($_POST['usuario']) ||
    !is_string($_POST['password'])
) {
    header("Location: login.php");
    exit;
}


// Recuperar las credenciales
$username = $_POST['usuario'];
$password = $_POST['password'];

// Buscar el usuario del sistema de persistencia
$usuario = getUsuarioByUserName($username);

// Comprobar las credenciales
if ($usuario !== null && password_verify($password, $usuario['password'])) {

    // Iniciar la sesión
    session_start();

    // Guardar la identidad del usuario
    $_SESSION['id_usuario'] = $usuario['id'];
    $_SESSION['usuario'] = $usuario['usuario'];
    $_SESSION['rol'] = $usuario['rol'];

    // Acceder a la página privada
    if($_SESSION['rol'] === 'admin'){
        header("Location: admin.php");
        exit;
    } else if ($_SESSION['rol'] === 'user'){
        header("Location: privada.php");
        exit;
     }

} else {

    session_start();

    $_SESSION['error_login'] = "Usuario o contraseña incorrectos.";

    // Credenciales incorrectas
    header("Location: login.php");
    exit;
}

